#!/bin/bash
echo "🔨 Build en cours..."
npm run build

echo "📦 Copie des fichiers..."
sudo mkdir -p /var/www/dental-stock
sudo cp -r dist/* /var/www/dental-stock/

echo "✅ Déployé ! Accessible sur http://stock.cabinetdrhazan.fr"
