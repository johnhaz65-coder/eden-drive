# 🦷 Cabinet Dr Hazan — Gestion de Stock
## Déploiement sur VPS

---

### Prérequis sur le VPS
```bash
# Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Nginx
sudo apt install nginx -y
```

---

### 1. Copier les fichiers sur le VPS

Depuis ta machine locale, upload le dossier sur ton VPS :
```bash
scp -r dental-stock/ user@TON_IP:/home/user/
```

Ou via SFTP (FileZilla, etc.)

---

### 2. Build de l'app sur le VPS

```bash
cd /home/user/dental-stock

# Installer les dépendances
npm install

# Build de production
npm run build
# → Génère le dossier /dist avec les fichiers statiques optimisés

# Copier dans le dossier web
sudo mkdir -p /var/www/dental-stock
sudo cp -r dist/* /var/www/dental-stock/
```

---

### 3. Configurer Nginx

```bash
# Copier la config nginx
sudo cp nginx.conf /etc/nginx/sites-available/dental-stock

# Activer le site
sudo ln -s /etc/nginx/sites-available/dental-stock /etc/nginx/sites-enabled/

# ⚠️ Édite le fichier et remplace "stock.cabinetdrhazan.fr" par ton domaine ou IP
sudo nano /etc/nginx/sites-available/dental-stock

# Tester la config
sudo nginx -t

# Recharger nginx
sudo systemctl reload nginx
```

---

### 4. (Optionnel) HTTPS avec Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d stock.cabinetdrhazan.fr
```

---

### 5. Accès

🌐 Ouvre ton navigateur sur : `http://TON_IP` ou `http://stock.cabinetdrhazan.fr`

---

### Mise à jour de l'app

Quand tu modifies l'app, re-build et re-copie :
```bash
npm run build
sudo cp -r dist/* /var/www/dental-stock/
```

---

### Script de déploiement rapide (deploy.sh)

```bash
#!/bin/bash
npm run build && sudo cp -r dist/* /var/www/dental-stock/ && echo "✅ Déployé !"
```

```bash
chmod +x deploy.sh
./deploy.sh
```
