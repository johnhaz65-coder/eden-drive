import { useState, useMemo } from "react";

const CATEGORIES = ["Consommables", "Matériaux dentaires", "Instruments", "Médicaments", "Equipement"];
const CATEGORY_COLORS = { "Consommables": "#C4956A", "Matériaux dentaires": "#8B7355", "Instruments": "#A0836B", "Médicaments": "#B5956B", "Equipement": "#7A9090" };
const CATEGORY_ICONS = { "Consommables": "🧤", "Matériaux dentaires": "🦷", "Instruments": "🔧", "Médicaments": "💊", "Equipement": "⚙️" };

const C = {
  bg: "#F5F0EA", sidebar: "#2C2520", sidebarBorder: "#3D312A",
  card: "#FFFFFF", cardBorder: "#E8DDD3",
  accent: "#C4956A", accentDark: "#A07550", accentLight: "#EDD9C3",
  text: "#2C2520", textMid: "#7A6558", textLight: "#A8968A",
  danger: "#C4674A", dangerBg: "#FAF0ED",
  warning: "#C49A4A", warningBg: "#FBF5E8",
  success: "#6A9A7A", successBg: "#EFF5F1",
  tableRow: "#FDFAF7", tableRowHover: "#F5EDE4", inputBg: "#FAF7F4",
};

const realProducts = [
  { id: 1, name: "GLACE INSTANTANEE 24u BESTDENT", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 9.99 },
  { id: 2, name: "CAVIT BLANC", category: "Matériaux dentaires", quantity: 3, minQuantity: 1, unit: "unités", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 12.57 },
  { id: 3, name: "TELIO INLAY UNIVERSAL 3 Jer.x2,5g", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "kits", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 43.09 },
  { id: 4, name: "FUJI I CIMENT CAPSULE 50u", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 94.58 },
  { id: 5, name: "PANAVIA V5 A2 +20 EMBTS", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 103.67 },
  { id: 6, name: "SOLVANT SPRAY ORANGE HAGER&WERKEN", category: "Consommables", quantity: 1, minQuantity: 2, unit: "spray", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 9.53 },
  { id: 7, name: "PORTE-EMPR MINITRAY PARTIEL JETABLE 50u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 16.58 },
  { id: 8, name: "HYPOCHLORITE SODIUM 5,25% 250ml", category: "Matériaux dentaires", quantity: 8, minQuantity: 4, unit: "flacons", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 5.34 },
  { id: 9, name: "CANALPRO SERINGUE 5ml BLEUES 50u", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 10.08 },
  { id: 10, name: "CANALPRO SERINGUE 5ml BLANCHES 50u", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 10.08 },
  { id: 11, name: "WEDJETS ORANGE", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 22.27 },
  { id: 12, name: "NEONITI A1 Ø.20 / 6% / L25 MM", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 53.96 },
  { id: 13, name: "PUNTA CORTADOR GUTTAMESTRA MEDIANA 1,2mm", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 11.08 },
  { id: 14, name: "FRAISE FG TUNGST 164 ENDO ACCES N°3", category: "Instruments", quantity: 4, minQuantity: 2, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 5.83 },
  { id: 15, name: "FRAISE FG TUNGST 164 ENDO ACCES N°2", category: "Instruments", quantity: 4, minQuantity: 2, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 5.83 },
  { id: 16, name: "EXO-PRINT 1L", category: "Consommables", quantity: 1, minQuantity: 2, unit: "flacon", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 21.30 },
  { id: 17, name: "GAINE STERILISAT. 5cmx200m BESTDENT", category: "Consommables", quantity: 3, minQuantity: 2, unit: "rouleaux", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 11.00 },
  { id: 18, name: "GAINE STERILISAT. 7,5cmx200m BESTDENT", category: "Consommables", quantity: 2, minQuantity: 2, unit: "rouleaux", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 10.08 },
  { id: 19, name: "SACHET STERILISATION 14X25CM", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 12.42 },
  { id: 20, name: "LINGETTES DESINFECT. RECH. 100u", category: "Consommables", quantity: 28, minQuantity: 5, unit: "recharges", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 1.92 },
  { id: 21, name: "OROTOL PLUS CONCENTRE 2,5L", category: "Consommables", quantity: 2, minQuantity: 2, unit: "bidons", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 34.16 },
  { id: 22, name: "COMPOSITE FLUIDE B2 SERINGUE 2g BESTDENT", category: "Matériaux dentaires", quantity: 3, minQuantity: 2, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-03-02", priceHT: 5.83 },
  { id: 23, name: "MATRICE ACETATE 6mm 15m KERR", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "rouleau", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 9.00 },
  { id: 24, name: "MATRICES METALLIQUES 0,03mm", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "rouleau", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 9.04 },
  { id: 25, name: "GEL MORD BLEU 1,2g BESTDENT", category: "Matériaux dentaires", quantity: 4, minQuantity: 2, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 5.83 },
  { id: 26, name: "COMPOSITE FLUIDE A2 SERINGUE 2g BD", category: "Matériaux dentaires", quantity: 5, minQuantity: 2, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 5.83 },
  { id: 27, name: "TETRIC EVOFLOW A1 SERINGUE 2gr", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 29.68 },
  { id: 28, name: "TETRIC EVOFLOW A2 SERINGUE 2gr", category: "Matériaux dentaires", quantity: 3, minQuantity: 1, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 29.68 },
  { id: 29, name: "TETRIC EVOFLOW A3 SERINGUE 2gr", category: "Matériaux dentaires", quantity: 3, minQuantity: 1, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 29.68 },
  { id: 30, name: "TETRIC EVOFLOW A3,5 SERINGUE 2gr", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "seringue", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 29.68 },
  { id: 31, name: "UNISHADE FLOW SERINGUE", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "seringue", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 35.99 },
  { id: 32, name: "TETRIC EVOCERAM A3 SERINGUE X3g", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "seringue", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 45.78 },
  { id: 33, name: "AUTOMATRIX NARROW-REGULAR 72u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 49.99 },
  { id: 34, name: "AUTOMATRIX MEDIUM-THIN 72u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 49.99 },
  { id: 35, name: "AUTOMATRIX MEDIUM-REGULAR 72u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 49.99 },
  { id: 36, name: "FUJI II LC CAPS A2", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 114.16 },
  { id: 37, name: "ASSURE PLUS BONDING RESIN 6ml", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "flacon", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 88.33 },
  { id: 38, name: "CLINPRO SERINGUE 1,2ml", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "seringues", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 14.90 },
  { id: 39, name: "OPALESCENCE PF 16% REGULAR 40u", category: "Matériaux dentaires", quantity: 3, minQuantity: 1, unit: "kits", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 154.50 },
  { id: 40, name: "F.I.T.T. KERR", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "kits", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 41.63 },
  { id: 41, name: "STRUCTUR 3 A1 CART 50ml", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "cartouche", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 90.83 },
  { id: 42, name: "STRUCTUR 3 A3 CARTOUCHE 50ml", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "cartouche", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 90.83 },
  { id: 43, name: "DOIGTIERS LATEX MEDIUM RVG 100u", category: "Consommables", quantity: 6, minQuantity: 3, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 1.13 },
  { id: 44, name: "RISKONTROL BLANC 250u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 20.67 },
  { id: 45, name: "PLATEAUX USAGE UNIQUE GRANDS 400u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 21.25 },
  { id: 46, name: "FILTRES ASPI JAUNE CANUL 12u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 21.42 },
  { id: 47, name: "RISKONTROL CLASSIC ROSE 250u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 22.08 },
  { id: 48, name: "RISKONTROL ART VIOLET", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2025-12-23", priceHT: 25.42 },
  { id: 49, name: "GANTS LATEX X-S BESTDENT", category: "Consommables", quantity: 23, minQuantity: 5, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 2.92 },
  { id: 50, name: "ARTINIBSA 1:200000 50 CART.", category: "Médicaments", quantity: 10, minQuantity: 3, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 25.42 },
  { id: 51, name: "XYLOROLLAND SANS VASOCONSTRICTEUR", category: "Médicaments", quantity: 1, minQuantity: 3, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 29.14 },
  { id: 52, name: "AIGUILLES 30G 21mm PERIAP 100u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 16.66 },
  { id: 53, name: "AIGUILLES 30G 21mm PROCLINIC 100u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 9.95 },
  { id: 54, name: "EPONGE HEMOSTATIQUE 10u BESTDENT", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 4.33 },
  { id: 55, name: "SUTURE PGA #4-0 INVERSE 3/8", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 40.83 },
  { id: 56, name: "PANAVIA V5 CLEAR KIT INTRO", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 104.17 },
  { id: 57, name: "PANAVIA V5 CLEAR +20 EMBTS", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 103.33 },
  { id: 58, name: "D-RACE NITI 30+25", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 38.87 },
  { id: 59, name: "ARC NITI SUPERELAST INF 020 10u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 7.08 },
  { id: 60, name: "ARC NITI SUPERELAST INF 012 10u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 7.08 },
  { id: 61, name: "FLOW TAIN", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 22.49 },
  { id: 62, name: "BAGUES UL N.20 RICKETTS", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 26.10 },
  { id: 63, name: "BAGUES UR N.20 RICKETTS", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 26.10 },
  { id: 64, name: "BAGUES UR N.14 RICKETTS", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 26.10 },
  { id: 65, name: "CROCHETS EXTRUS HOOK CHAINE ARGENT", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 26.49 },
  { id: 66, name: "COPPER NITI EFII INF 014", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-03", priceHT: 28.86 },
  { id: 67, name: "COPPER NITI EFII INF 018", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 28.86 },
  { id: 68, name: "COPPER NITI EFII SUP 012", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 28.86 },
  { id: 69, name: "COPPER NITI EFII SUP 014", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 28.86 },
  { id: 70, name: "COPPER NITI EFII SUP 016", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 28.86 },
  { id: 71, name: "COPPER NITI EFII SUP 018", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 28.86 },
  { id: 72, name: "COPPER NITI EFII SUP 020", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 28.86 },
  { id: 73, name: "BOUTON LINGUAL CERAMIQUE 10u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 31.50 },
  { id: 74, name: "MASQUES BLANCS MONOART 50u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 4.00 },
  { id: 75, name: "MASQUES LILAS MONOART 50u", category: "Consommables", quantity: 2, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-07", priceHT: 4.00 },
  { id: 76, name: "MASQUES BLEU LAGON 50u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.00 },
  { id: 77, name: "MASQUES ROSES MONOART 50u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.00 },
  { id: 78, name: "GANTS LATEX S BESTDENT", category: "Consommables", quantity: 15, minQuantity: 5, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 2.92 },
  { id: 79, name: "GANTS LATEX M BESTDENT", category: "Consommables", quantity: 15, minQuantity: 5, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 2.92 },
  { id: 80, name: "POMPES SALIVE DIVERSES 100u", category: "Consommables", quantity: 7, minQuantity: 3, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 2.87 },
  { id: 81, name: "CANULE UNIV. PETITO 16MM ROSE 5u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 11.66 },
  { id: 82, name: "TEMPBOND CLEAR AUTOMIX 6gr", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "seringue", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 42.42 },
  { id: 83, name: "POLY-CORE HD", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 156.82 },
  { id: 84, name: "PERMLASTIC REGULAR BODY 2X60ml", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 28.33 },
  { id: 85, name: "LIMES K N.08 25mm BESTDENT", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.33 },
  { id: 86, name: "LIMES K N.10 25mm BESTDENT", category: "Matériaux dentaires", quantity: 2, minQuantity: 1, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.33 },
  { id: 87, name: "DIGUES BLEUES NICTONE MOY 36u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 12.08 },
  { id: 88, name: "NEONITI A1 Ø.25 / 6% / L25 MM", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 53.96 },
  { id: 89, name: "OPTIBOND EXTRA UNIV PRIMER RECH", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "flacon", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 81.35 },
  { id: 90, name: "OPTIBOND EXTRA UNI ADHESIF RECH", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "flacon", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 81.35 },
  { id: 91, name: "MASQUE FACIAL AJUSTABLE GRAFFITI", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 23.09 },
  { id: 92, name: "MASQUE FACIAL AJUSTABLE FLOWER", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 23.09 },
  { id: 93, name: "FLUOR PROTECTOR S 7g", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "flacon", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 46.62 },
  { id: 94, name: "TENON FIBRE VERRE 1,2mm 5u BESTDENT", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 13.33 },
  { id: 95, name: "TENON FIBRE VERRE 1,4mm 5u BESTDENT", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 13.33 },
  { id: 96, name: "TENONS CYL.CON.INOX 11,4MM 20U", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 37.80 },
  { id: 97, name: "PUNTA CORTADOR GUTTAMESTRA PEQUEÑA", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 11.08 },
  { id: 98, name: "BROSSE CARDE FRAISES LAITON", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 2.50 },
  { id: 99, name: "FRAISE TUNGSTENE PM H141A", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 26.69 },
  { id: 100, name: "FRAISE FG TUNG CHIR ZEKRYA N°151", category: "Instruments", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 41.17 },
  { id: 101, name: "SQ RC TITANE JAUNE CORPORIS 3 ALESOIRS", category: "Instruments", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-01-29", priceHT: 109.55 },
  { id: 102, name: "V-PROPHY FLOW RACCORD KAVO", category: "Equipement", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-03", priceHT: 415.83 },
  { id: 103, name: "BICARBONATE AIR-FLOW CERISE 4X300gr", category: "Consommables", quantity: 1, minQuantity: 2, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-03", priceHT: 91.66 },
  { id: 104, name: "ICON VESTIBULAIRE 2u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-03", priceHT: 132.08 },
  { id: 105, name: "BIODENTINE SEPTODONT 5 CAPSULES", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 69.30 },
  { id: 106, name: "LIME C+ 06 25mm", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 13.00 },
  { id: 107, name: "LIMES RECIPROC BLUE R25 31mm 6u", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 80.82 },
  { id: 108, name: "FRAISE FLAMME LONGUE 863 012F", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 33.08 },
  { id: 109, name: "TEST BOWIE&DICK 20u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 47.49 },
  { id: 110, name: "MANCHE PINCEAU JETABLE", category: "Consommables", quantity: 4, minQuantity: 2, unit: "boîtes", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 1.08 },
  { id: 111, name: "PINCEAUX JETABLE ADHESIF 100u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.58 },
  { id: 112, name: "ACIDE GEL VERT 3x3,5g PROCLINIC", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 10.75 },
  { id: 113, name: "ETCH ULTRADENT PORCELAINE", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "seringue", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 26.33 },
  { id: 114, name: "SERINGUES TRANSBOND XT", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "kit", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 162.42 },
  { id: 115, name: "COMPOSITE PREPOLISHER CA JAUNE", category: "Matériaux dentaires", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 26.43 },
  { id: 116, name: "POLISSOIR DIACOMP PLUS DCP1m", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 4.75 },
  { id: 117, name: "POLISSOIR DIACOMP PLUS TWIST M", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 7.04 },
  { id: 118, name: "POLISSOIR DIACOMP PLUS TWIST F", category: "Instruments", quantity: 1, minQuantity: 1, unit: "pcs", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 7.04 },
  { id: 119, name: "BOULETTES COTON N.1 Ø 6,3mm ROEKO", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 15.23 },
  { id: 120, name: "SERVIETTE 40x40 BLEU 3 PLIS 1500u", category: "Consommables", quantity: 1, minQuantity: 2, unit: "boîte", expiryDate: null, supplier: "Dentalclick", lastOrder: "2026-02-17", priceHT: 40.83 },
];

const realOrders = [
  { id: 1, date: "2025-12-23", ref: "0040058742", supplier: "Dentalclick", items: "Ciments, Endodontie, Hygiène, Obturation, Anesthésie (50+ articles)", total: 2308.56, status: "Livré" },
  { id: 2, date: "2026-01-07", ref: "0040070785", supplier: "Dentalclick", items: "Anesthésie, Orthodontie, Consommables (24 articles)", total: 962.54, status: "Livré" },
  { id: 3, date: "2026-01-29", ref: "0040116706", supplier: "Dentalclick", items: "Ciments, Endodontie, Obturation, Orthodontie, Usage unique (40+ articles)", total: 1653.17, status: "Livré" },
  { id: 4, date: "2026-02-03", ref: "0040125924", supplier: "Dentalclick", items: "V-Prophy KAVO, Orthodontie, Air-Flow, ICON (5 articles)", total: 836.75, status: "Livré" },
  { id: 5, date: "2026-02-17", ref: "0040154317", supplier: "Dentalclick", items: "Copper NiTi EFII SUP 016 + 020", total: 69.26, status: "Livré" },
  { id: 6, date: "2026-02-17", ref: "0040152742", supplier: "Dentalclick", items: "Biodentine, Reciproc, Transbond XT, Opalescence, Lingettes (30+ articles)", total: 1370.99, status: "Livré" },
  { id: 7, date: "2026-03-02", ref: "0040177970", supplier: "Dentalclick", items: "Composite Fluide B2 x2 seringues", total: 13.99, status: "Livré" },
];

function formatDate(d) { if (!d) return "—"; return new Date(d).toLocaleDateString("fr-FR"); }
function daysUntilExpiry(d) { if (!d) return null; return Math.ceil((new Date(d) - new Date()) / 86400000); }

export default function App() {
  const [view, setView] = useState("dashboard");
  const [products, setProducts] = useState(realProducts);
  const [orders, setOrders] = useState(realOrders);
  const [movements, setMovements] = useState([]);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showMoveModal, setShowMoveModal] = useState(null);
  const [showAddOrder, setShowAddOrder] = useState(false);
  const [filterCat, setFilterCat] = useState("Tous");
  const [searchQ, setSearchQ] = useState("");
  const [newProduct, setNewProduct] = useState({ name: "", category: "Consommables", quantity: 0, minQuantity: 0, unit: "", expiryDate: "", supplier: "Dentalclick" });
  const [moveData, setMoveData] = useState({ type: "sortie", qty: 1, reason: "" });
  const [newOrder, setNewOrder] = useState({ supplier: "Dentalclick", items: "", total: "", status: "En cours", ref: "" });

  const lowStock = products.filter(p => p.quantity <= p.minQuantity);
  const expiringSoon = products.filter(p => { const d = daysUntilExpiry(p.expiryDate); return d !== null && d <= 60; });

  const filteredProducts = useMemo(() => products.filter(p => {
    const matchCat = filterCat === "Tous" || p.category === filterCat;
    const matchSearch = p.name.toLowerCase().includes(searchQ.toLowerCase());
    return matchCat && matchSearch;
  }), [products, filterCat, searchQ]);

  function addProduct() {
    if (!newProduct.name) return;
    setProducts(prev => [...prev, { ...newProduct, id: Date.now(), quantity: Number(newProduct.quantity), minQuantity: Number(newProduct.minQuantity), lastOrder: new Date().toISOString().split("T")[0] }]);
    setNewProduct({ name: "", category: "Consommables", quantity: 0, minQuantity: 0, unit: "", expiryDate: "", supplier: "Dentalclick" });
    setShowAddProduct(false);
  }

  function applyMovement() {
    const qty = Number(moveData.qty);
    const product = showMoveModal;
    setProducts(prev => prev.map(p => p.id === product.id
      ? { ...p, quantity: moveData.type === "entrée" ? p.quantity + qty : Math.max(0, p.quantity - qty) }
      : p
    ));
    setMovements(prev => [{ id: Date.now(), productId: product.id, productName: product.name, type: moveData.type, qty, reason: moveData.reason, date: new Date().toISOString() }, ...prev]);
    setShowMoveModal(null);
    setMoveData({ type: "sortie", qty: 1, reason: "" });
  }

  function addOrder() {
    if (!newOrder.supplier || !newOrder.items) return;
    setOrders(prev => [{ ...newOrder, id: Date.now(), date: new Date().toISOString().split("T")[0], total: Number(newOrder.total) }, ...prev]);
    setNewOrder({ supplier: "Dentalclick", items: "", total: "", status: "En cours", ref: "" });
    setShowAddOrder(false);
  }

  const statsPerCat = CATEGORIES.map(cat => ({
    cat, count: products.filter(p => p.category === cat).length,
    low: products.filter(p => p.category === cat && p.quantity <= p.minQuantity).length,
  }));

  const totalValeurHT = products.reduce((s, p) => s + (p.quantity * (p.priceHT || 0)), 0);
  const totalDepenses3Mois = orders.reduce((s, o) => s + o.total, 0);

  const NAV = [
    { id: "dashboard", label: "Tableau de bord", icon: "◈" },
    { id: "stock", label: "Stock", icon: "▦" },
    { id: "movements", label: "Mouvements", icon: "⇅" },
    { id: "orders", label: "Commandes", icon: "◻" },
    { id: "expiry", label: "Péremptions", icon: "◷" },
  ];

  return (
    <div style={{ fontFamily: "'Georgia', serif", background: C.bg, minHeight: "100vh", color: C.text, display: "flex" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=DM+Sans:wght@300;400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 5px; } ::-webkit-scrollbar-track { background: ${C.bg}; } ::-webkit-scrollbar-thumb { background: ${C.accentLight}; border-radius: 99px; }
        .nav-btn { background: none; border: none; color: #9A8478; cursor: pointer; padding: 10px 14px; border-radius: 8px; font-family: 'DM Sans', sans-serif; font-size: 12px; font-weight: 400; display: flex; align-items: center; gap: 10px; width: 100%; transition: all 0.2s; }
        .nav-btn:hover { background: #3D312A; color: #D4B896; }
        .nav-btn.active { background: #3D312A; color: #EDD9C3; border-left: 2px solid #C4956A; padding-left: 12px; }
        .card { background: #fff; border: 1px solid ${C.cardBorder}; border-radius: 16px; padding: 24px; box-shadow: 0 2px 12px rgba(44,37,32,0.06); }
        .btn { border: none; cursor: pointer; border-radius: 8px; font-family: 'DM Sans', sans-serif; font-size: 12px; font-weight: 500; padding: 9px 18px; transition: all 0.2s; }
        .btn-primary { background: ${C.accent}; color: #fff; }
        .btn-primary:hover { background: ${C.accentDark}; }
        .btn-ghost { background: ${C.accentLight}; color: ${C.accentDark}; }
        .btn-ghost:hover { background: #E0C8A8; }
        .input { background: ${C.inputBg}; border: 1px solid ${C.cardBorder}; border-radius: 8px; padding: 9px 13px; color: ${C.text}; font-size: 13px; font-family: 'DM Sans', sans-serif; outline: none; width: 100%; transition: border 0.2s; }
        .input:focus { border-color: ${C.accent}; box-shadow: 0 0 0 3px ${C.accentLight}55; }
        select.input option { background: #fff; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(44,37,32,0.5); display: flex; align-items: center; justify-content: center; z-index: 100; backdrop-filter: blur(6px); }
        .modal { background: #fff; border: 1px solid ${C.cardBorder}; border-radius: 20px; padding: 32px; width: 460px; max-width: 95vw; box-shadow: 0 20px 60px rgba(44,37,32,0.2); }
        .lbl { font-family: 'DM Sans', sans-serif; font-size: 10px; color: ${C.textLight}; letter-spacing: 0.12em; text-transform: uppercase; margin-bottom: 5px; }
        .tag { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-family: 'DM Sans', sans-serif; }
        .progress-bar { background: ${C.bg}; border-radius: 99px; height: 5px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 99px; transition: width 0.4s; }
        tr { transition: background 0.12s; }
        tr:hover td { background: ${C.tableRowHover} !important; }
        .tt { font-family: 'Cormorant Garamond', serif; font-weight: 600; font-size: 26px; }
        .ts { font-family: 'DM Sans', sans-serif; font-size: 12px; color: ${C.textLight}; margin-top: 3px; }
        th { padding: 11px 16px; text-align: left; font-family: 'DM Sans', sans-serif; font-size: 10px; color: ${C.textLight}; letter-spacing: 0.12em; font-weight: 500; text-transform: uppercase; }
      `}</style>

      {/* Sidebar */}
      <div style={{ width: 220, background: C.sidebar, borderRight: `1px solid ${C.sidebarBorder}`, padding: "28px 12px", display: "flex", flexDirection: "column", gap: 2, flexShrink: 0 }}>
        <div style={{ padding: "0 8px 22px", borderBottom: `1px solid ${C.sidebarBorder}`, marginBottom: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🦷</div>
            <div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 18, color: "#F5EDE3", lineHeight: 1.1 }}>Dr Hazan</div>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 9, color: "#7A6558", letterSpacing: "0.15em", textTransform: "uppercase" }}>Cabinet Dentaire</div>
            </div>
          </div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 9, color: "#5A4840", letterSpacing: "0.15em", textTransform: "uppercase", paddingTop: 10, borderTop: `1px solid ${C.sidebarBorder}` }}>Gestion de Stock</div>
        </div>

        {NAV.map(n => (
          <button key={n.id} className={`nav-btn ${view === n.id ? "active" : ""}`} onClick={() => setView(n.id)}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>{n.icon}</span>
            <span>{n.label}</span>
            {n.id === "dashboard" && lowStock.length > 0 && (
              <span style={{ marginLeft: "auto", background: C.danger, color: "#fff", borderRadius: "99px", fontSize: 9, padding: "1px 7px", fontWeight: 600 }}>{lowStock.length}</span>
            )}
          </button>
        ))}

        <div style={{ marginTop: "auto", padding: "16px 8px 0", borderTop: `1px solid ${C.sidebarBorder}` }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: "#5A4840" }}>{products.length} produits · {lowStock.length} alerte{lowStock.length > 1 ? "s" : ""}</div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: "#5A4840", marginTop: 3 }}>{new Date().toLocaleDateString("fr-FR")}</div>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflow: "auto", padding: "32px 36px" }}>

        {/* DASHBOARD */}
        {view === "dashboard" && (
          <div>
            <div style={{ marginBottom: 28 }}>
              <div className="tt">Bonjour, Dr Hazan 👋</div>
              <div className="ts">{new Date().toLocaleDateString("fr-FR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
              {[
                { label: "Produits", value: products.length, sub: "en stock", color: C.accent },
                { label: "Alertes", value: lowStock.length, sub: "stock bas", color: C.danger },
                { label: "Valeur stock", value: `${Math.round(totalValeurHT).toLocaleString("fr-FR")} €`, sub: "HT estimée", color: C.success, big: true },
                { label: "Dépenses 3 mois", value: `${Math.round(totalDepenses3Mois).toLocaleString("fr-FR")} €`, sub: "TTC Dentalclick", color: C.warning, big: true },
              ].map((k, i) => (
                <div key={i} className="card">
                  <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>{k.label}</div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: k.big ? 26 : 40, color: k.color, lineHeight: 1 }}>{k.value}</div>
                  <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textMid, marginTop: 4 }}>{k.sub}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
              <div className="card">
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 18 }}>Par catégorie</div>
                {statsPerCat.map(s => (
                  <div key={s.cat} style={{ marginBottom: 14 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13 }}>{CATEGORY_ICONS[s.cat]} {s.cat}</span>
                      <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight }}>
                        {s.count} prod.{s.low > 0 && <span style={{ color: C.danger }}> · {s.low} alerte{s.low > 1 ? "s" : ""}</span>}
                      </span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${(s.count / products.length) * 100}%`, background: CATEGORY_COLORS[s.cat] }} />
                    </div>
                  </div>
                ))}
              </div>

              <div className="card">
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 18 }}>Alertes stock bas</div>
                {lowStock.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "24px 0" }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>✓</div>
                    <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: C.success }}>Tout est approvisionné</div>
                  </div>
                ) : lowStock.slice(0, 6).map(p => (
                  <div key={p.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", background: C.dangerBg, border: `1px solid ${C.danger}25`, borderRadius: 8, marginBottom: 7 }}>
                    <div>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: C.textLight }}>{p.category}</div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontFamily: "'Cormorant Garamond', serif", color: C.danger, fontWeight: 600, fontSize: 18 }}>{p.quantity}</div>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: C.textLight }}>min · {p.minQuantity}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent orders summary */}
            <div className="card">
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 18 }}>Dernières commandes Dentalclick</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {orders.slice(0, 4).map(o => (
                  <div key={o.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", background: C.bg, borderRadius: 10 }}>
                    <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight, minWidth: 80 }}>{formatDate(o.date)}</div>
                      <div>
                        <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500 }}>Réf. {o.ref}</div>
                        <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: C.textLight }}>{o.items}</div>
                      </div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 18, color: C.accent }}>{o.total.toLocaleString("fr-FR")} €</div>
                      <span className="tag" style={{ background: C.successBg, color: C.success, border: `1px solid ${C.success}30`, fontSize: 10 }}>{o.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STOCK */}
        {view === "stock" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
              <div><div className="tt">Stock</div><div className="ts">{filteredProducts.length} produits · {filterCat !== "Tous" ? filterCat : "toutes catégories"}</div></div>
              <button className="btn btn-primary" onClick={() => setShowAddProduct(true)}>+ Nouveau produit</button>
            </div>
            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
              <input className="input" placeholder="🔍 Rechercher..." style={{ maxWidth: 240 }} value={searchQ} onChange={e => setSearchQ(e.target.value)} />
              {["Tous", ...CATEGORIES].map(cat => (
                <button key={cat} className="btn" onClick={() => setFilterCat(cat)}
                  style={{ background: filterCat === cat ? C.accent : C.accentLight, color: filterCat === cat ? "#fff" : C.accentDark, fontSize: 11 }}>
                  {cat === "Tous" ? "Tous" : CATEGORY_ICONS[cat] + " " + (cat.length > 10 ? cat.split(" ")[0] : cat)}
                </button>
              ))}
            </div>
            <div className="card" style={{ padding: 0, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: C.bg, borderBottom: `1px solid ${C.cardBorder}` }}>
                    {["Produit", "Catégorie", "Qté", "Seuil", "Dernier achat", "Prix HT", ""].map(h => <th key={h}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((p, i) => {
                    const isLow = p.quantity <= p.minQuantity;
                    return (
                      <tr key={p.id} style={{ borderBottom: `1px solid ${C.cardBorder}`, background: i % 2 === 0 ? "#fff" : C.tableRow }}>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 12, fontWeight: 500, maxWidth: 220 }}>
                          <div style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                        </td>
                        <td style={{ padding: "11px 16px" }}>
                          <span className="tag" style={{ background: `${CATEGORY_COLORS[p.category]}18`, color: CATEGORY_COLORS[p.category], border: `1px solid ${CATEGORY_COLORS[p.category]}35`, fontSize: 10 }}>
                            {CATEGORY_ICONS[p.category]} {p.category.split(" ")[0]}
                          </span>
                        </td>
                        <td style={{ padding: "11px 16px" }}>
                          <span style={{ fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 18, color: isLow ? C.danger : C.text }}>{p.quantity}</span>
                          <span style={{ fontFamily: "'DM Sans',sans-serif", color: C.textLight, fontSize: 11 }}> {p.unit}</span>
                          {isLow && <span style={{ marginLeft: 5, fontSize: 10, color: C.danger, background: C.dangerBg, padding: "1px 5px", borderRadius: 3, fontFamily: "'DM Sans',sans-serif" }}>⚠</span>}
                        </td>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textLight }}>{p.minQuantity}</td>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textLight }}>{formatDate(p.lastOrder)}</td>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textMid }}>{p.priceHT ? `${p.priceHT.toFixed(2)} €` : "—"}</td>
                        <td style={{ padding: "11px 16px" }}>
                          <button className="btn btn-ghost" style={{ fontSize: 11, padding: "5px 12px" }} onClick={() => setShowMoveModal(p)}>⇅</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* MOVEMENTS */}
        {view === "movements" && (
          <div>
            <div style={{ marginBottom: 24 }}><div className="tt">Mouvements</div><div className="ts">Historique entrées / sorties</div></div>
            {movements.length === 0 ? (
              <div className="card" style={{ textAlign: "center", padding: 60 }}>
                <div style={{ fontSize: 36, marginBottom: 14, opacity: 0.2 }}>⇅</div>
                <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 14, color: C.textMid }}>Aucun mouvement enregistré</div>
                <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 12, color: C.textLight, marginTop: 4 }}>Utilisez le bouton ⇅ sur un produit</div>
              </div>
            ) : (
              <div className="card" style={{ padding: 0, overflow: "hidden" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr style={{ background: C.bg, borderBottom: `1px solid ${C.cardBorder}` }}>
                    {["Date", "Produit", "Type", "Quantité", "Motif"].map(h => <th key={h}>{h}</th>)}
                  </tr></thead>
                  <tbody>
                    {movements.map((m, i) => (
                      <tr key={m.id} style={{ borderBottom: `1px solid ${C.cardBorder}`, background: i % 2 === 0 ? "#fff" : C.tableRow }}>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textLight }}>{new Date(m.date).toLocaleString("fr-FR")}</td>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 12, fontWeight: 500 }}>{m.productName}</td>
                        <td style={{ padding: "11px 16px" }}>
                          <span className="tag" style={{ background: m.type === "entrée" ? C.successBg : C.dangerBg, color: m.type === "entrée" ? C.success : C.danger, border: `1px solid ${m.type === "entrée" ? C.success : C.danger}30` }}>
                            {m.type === "entrée" ? "↑ Entrée" : "↓ Sortie"}
                          </span>
                        </td>
                        <td style={{ padding: "11px 16px", fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 18, color: m.type === "entrée" ? C.success : C.danger }}>
                          {m.type === "entrée" ? "+" : "-"}{m.qty}
                        </td>
                        <td style={{ padding: "11px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 12, color: C.textMid }}>{m.reason || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ORDERS */}
        {view === "orders" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
              <div>
                <div className="tt">Commandes fournisseurs</div>
                <div className="ts">{orders.length} commandes · Total : {Math.round(totalDepenses3Mois).toLocaleString("fr-FR")} € TTC</div>
              </div>
              <button className="btn btn-primary" onClick={() => setShowAddOrder(true)}>+ Nouvelle commande</button>
            </div>
            <div className="card" style={{ padding: 0, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead><tr style={{ background: C.bg, borderBottom: `1px solid ${C.cardBorder}` }}>
                  {["Date", "Référence", "Fournisseur", "Articles", "Total TTC", "Statut"].map(h => <th key={h}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {orders.map((o, i) => (
                    <tr key={o.id} style={{ borderBottom: `1px solid ${C.cardBorder}`, background: i % 2 === 0 ? "#fff" : C.tableRow }}>
                      <td style={{ padding: "12px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 12, color: C.textLight }}>{formatDate(o.date)}</td>
                      <td style={{ padding: "12px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.accent, fontWeight: 500 }}>{o.ref || "—"}</td>
                      <td style={{ padding: "12px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 13, fontWeight: 500 }}>{o.supplier}</td>
                      <td style={{ padding: "12px 16px", fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textMid, maxWidth: 200 }}>{o.items}</td>
                      <td style={{ padding: "12px 16px", fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 18, color: C.accent }}>{o.total.toLocaleString("fr-FR")} €</td>
                      <td style={{ padding: "12px 16px" }}>
                        <span className="tag" style={{ background: o.status === "Livré" ? C.successBg : C.warningBg, color: o.status === "Livré" ? C.success : C.warning, border: `1px solid ${o.status === "Livré" ? C.success : C.warning}30`, fontSize: 10 }}>{o.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* EXPIRY */}
        {view === "expiry" && (
          <div>
            <div style={{ marginBottom: 24 }}><div className="tt">Dates de péremption</div><div className="ts">Classées par urgence</div></div>
            {products.filter(p => p.expiryDate).length === 0 ? (
              <div className="card" style={{ textAlign: "center", padding: 60 }}>
                <div style={{ fontSize: 36, marginBottom: 14, opacity: 0.2 }}>◷</div>
                <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 14, color: C.textMid }}>Aucune date de péremption enregistrée</div>
                <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 12, color: C.textLight, marginTop: 4 }}>Ajoutez des dates lors de la réception des commandes</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {products.filter(p => p.expiryDate).sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate)).map(p => {
                  const days = daysUntilExpiry(p.expiryDate);
                  const color = days < 0 ? C.danger : days < 30 ? C.warning : days < 60 ? "#B5A060" : C.success;
                  const bg = days < 0 ? C.dangerBg : days < 30 ? C.warningBg : days < 60 ? "#FBF8ED" : C.successBg;
                  const label = days < 0 ? "EXPIRÉ" : days < 30 ? "URGENT" : days < 60 ? "ATTENTION" : "OK";
                  return (
                    <div key={p.id} className="card" style={{ background: bg, border: `1px solid ${color}25`, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 20px" }}>
                      <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                        <div style={{ width: 3, height: 40, background: color, borderRadius: 2, flexShrink: 0 }} />
                        <div>
                          <div style={{ fontFamily: "'DM Sans',sans-serif", fontWeight: 500, fontSize: 13 }}>{p.name}</div>
                          <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textLight, marginTop: 2 }}>{CATEGORY_ICONS[p.category]} {p.category} · {p.supplier}</div>
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontFamily: "'DM Sans',sans-serif", color, fontWeight: 600, fontSize: 13 }}>{days < 0 ? `Expiré depuis ${Math.abs(days)} jours` : `${days} jours restants`}</div>
                          <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 11, color: C.textLight }}>{formatDate(p.expiryDate)}</div>
                        </div>
                        <span className="tag" style={{ background: `${color}15`, color, border: `1px solid ${color}30`, fontSize: 10, letterSpacing: "0.1em" }}>{label}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* MODAL - Add Product */}
      {showAddProduct && (
        <div className="modal-overlay" onClick={() => setShowAddProduct(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 22, marginBottom: 22 }}>Nouveau produit</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
              <div><div className="lbl">Nom</div><input className="input" placeholder="Ex: CAVIT W" value={newProduct.name} onChange={e => setNewProduct(p => ({ ...p, name: e.target.value }))} /></div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div><div className="lbl">Catégorie</div>
                  <select className="input" value={newProduct.category} onChange={e => setNewProduct(p => ({ ...p, category: e.target.value }))}>
                    {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div><div className="lbl">Unité</div><input className="input" placeholder="boîtes, pcs..." value={newProduct.unit} onChange={e => setNewProduct(p => ({ ...p, unit: e.target.value }))} /></div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div><div className="lbl">Quantité actuelle</div><input className="input" type="number" value={newProduct.quantity} onChange={e => setNewProduct(p => ({ ...p, quantity: e.target.value }))} /></div>
                <div><div className="lbl">Seuil d'alerte</div><input className="input" type="number" value={newProduct.minQuantity} onChange={e => setNewProduct(p => ({ ...p, minQuantity: e.target.value }))} /></div>
              </div>
              <div><div className="lbl">Date de péremption (optionnel)</div><input className="input" type="date" value={newProduct.expiryDate} onChange={e => setNewProduct(p => ({ ...p, expiryDate: e.target.value }))} /></div>
              <div><div className="lbl">Fournisseur</div><input className="input" value={newProduct.supplier} onChange={e => setNewProduct(p => ({ ...p, supplier: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowAddProduct(false)}>Annuler</button>
              <button className="btn btn-primary" style={{ flex: 2 }} onClick={addProduct}>Ajouter au stock</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL - Movement */}
      {showMoveModal && (
        <div className="modal-overlay" onClick={() => setShowMoveModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 22, marginBottom: 4 }}>Mouvement de stock</div>
            <div style={{ fontFamily: "'DM Sans',sans-serif", fontSize: 12, color: C.textLight, marginBottom: 20 }}>{showMoveModal.name}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div style={{ display: "flex", gap: 0, background: C.bg, borderRadius: 10, padding: 4 }}>
                {["sortie", "entrée"].map(t => (
                  <button key={t} className="btn" onClick={() => setMoveData(m => ({ ...m, type: t }))}
                    style={{ flex: 1, background: moveData.type === t ? (t === "entrée" ? C.successBg : C.dangerBg) : "transparent", color: moveData.type === t ? (t === "entrée" ? C.success : C.danger) : C.textLight, border: moveData.type === t ? `1px solid ${t === "entrée" ? C.success : C.danger}40` : "1px solid transparent" }}>
                    {t === "entrée" ? "↑ Entrée en stock" : "↓ Sortie / utilisation"}
                  </button>
                ))}
              </div>
              <div><div className="lbl">Quantité</div><input className="input" type="number" min="1" value={moveData.qty} onChange={e => setMoveData(m => ({ ...m, qty: e.target.value }))} /></div>
              <div><div className="lbl">Motif (optionnel)</div><input className="input" placeholder="Soin, commande reçue..." value={moveData.reason} onChange={e => setMoveData(m => ({ ...m, reason: e.target.value }))} /></div>
              <div style={{ padding: "12px 16px", background: C.bg, borderRadius: 10, fontFamily: "'DM Sans',sans-serif", fontSize: 13, color: C.textMid }}>
                Stock actuel : <span style={{ fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 18, color: C.text }}>{showMoveModal.quantity}</span>
                <span style={{ color: moveData.type === "entrée" ? C.success : C.danger, fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 18 }}>
                  {" → "}{moveData.type === "entrée" ? showMoveModal.quantity + Number(moveData.qty) : Math.max(0, showMoveModal.quantity - Number(moveData.qty))}
                </span>
                <span style={{ color: C.textLight }}> {showMoveModal.unit}</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowMoveModal(null)}>Annuler</button>
              <button className="btn btn-primary" style={{ flex: 2 }} onClick={applyMovement}>Valider</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL - Add Order */}
      {showAddOrder && (
        <div className="modal-overlay" onClick={() => setShowAddOrder(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, fontSize: 22, marginBottom: 22 }}>Nouvelle commande</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div><div className="lbl">Fournisseur</div><input className="input" value={newOrder.supplier} onChange={e => setNewOrder(o => ({ ...o, supplier: e.target.value }))} /></div>
                <div><div className="lbl">Référence</div><input className="input" placeholder="N° facture" value={newOrder.ref} onChange={e => setNewOrder(o => ({ ...o, ref: e.target.value }))} /></div>
              </div>
              <div><div className="lbl">Articles commandés</div><input className="input" placeholder="Ex: Tetric A2, Gants S x5..." value={newOrder.items} onChange={e => setNewOrder(o => ({ ...o, items: e.target.value }))} /></div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div><div className="lbl">Montant TTC (€)</div><input className="input" type="number" placeholder="0" value={newOrder.total} onChange={e => setNewOrder(o => ({ ...o, total: e.target.value }))} /></div>
                <div><div className="lbl">Statut</div>
                  <select className="input" value={newOrder.status} onChange={e => setNewOrder(o => ({ ...o, status: e.target.value }))}>
                    <option>En cours</option><option>Livré</option><option>Annulé</option>
                  </select>
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowAddOrder(false)}>Annuler</button>
              <button className="btn btn-primary" style={{ flex: 2 }} onClick={addOrder}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
